package com.coderising.download.api;

public class ConnectionException extends Exception {

}
